import chalk from "chalk";
import inquirer from "inquirer";
import gradient from "gradient-string";
import chalkAnimation from 'chalk-animation';
import figlet from "figlet";
import { createSpinner } from "nanospinner";

console.log(chalk.bgBlueBright('ADITYA HERE !!!'));

let playerName;

const sleep = (ms = 2000) => new Promise((r) => setTimeout(r, ms));

async function welcome() {
    const rainbowTitle = chalkAnimation.rainbow(
        "Welcome to my project\n"
    );

    await sleep();
    rainbowTitle.stop();

    console.log(`        
        ${chalk.bgBlue('HOW TO PLAY')}
        I am a process on your computer.
        If you get any question wrong I will be ${chalk.bgRed('killed')}
        So get all the Questions right...
        
        
        `);
}

async function askName() {
    const answers = await inquirer.prompt({
        name: 'player_name',
        type: 'input',
        message: 'What is your name?',
        default() {
            return 'Player';
        },
    });

    playerName = answers.player_name;
}

async function question1() {
    const answers = await inquirer.prompt({
        name: 'question_1',
        type: 'list',
        message: 'Question 1) A train 120 meters long is running at a speed of 60 km/h. How long will it take to pass a platform 180 meters long?\n',
        choices: [
            'A) 6 seconds',
            'B) 12 seconds',
            'C) 18 seconds',
            'D) 24 seconds'
        ],
    });

    return handleAnswer(answers.question_1 === 'C) 18 seconds');
}

async function handleAnswer(isCorrect) {
    const spinner = createSpinner('Checking answer...').start();
    await sleep(1000);

    if (isCorrect) {
        spinner.success({ text: `Nice work ${playerName}. That's a legit answer!` });
    } else {
        spinner.error({ text: `Game Over, You Lose ${playerName}` });
        process.exit(1);
    }
}

async function question2() {
    const answers = await inquirer.prompt({
        name: 'question_2',
        type: 'list',
        message: 'Question 2) If "Some cats are dogs" and "No dogs are cows," which of the following conclusions is logically valid?\n',
        choices: [
            'A) Some cats are cows',
            'B) No cats are cows',
            'C) Some cats are not cows',
            'D) All cats are dogs'
        ],
    });

    return handleAnswer(answers.question_2 === 'C) Some cats are not cows');
}

async function question3() {
    const answers = await inquirer.prompt({
        name: 'question_3',
        type: 'list',
        message: 'Question 3) Choose the word which is most nearly the same in meaning as the word "prolific."\n',
        choices: [
            'A) Productive',
            'B) Unproductive',
            'C) Rare',
            'D) Sparse'
        ],
    });

    return handleAnswer(answers.question_3 === 'A) Productive');
}

async function question4() {
    const answers = await inquirer.prompt({
        name: 'question_4',
        type: 'list',
        message: 'Question 4) What is 50% of 100?\n',
        choices: [
            'A) 25%',
            'B) 33.33%',
            'C) 50%',
            'D) 66.67%'
        ],
    });

    return handleAnswer(answers.question_4 === 'C) 50%');
}

async function question5() {
    const answers = await inquirer.prompt({
        name: 'question_5',
        type: 'list',
        message: 'Question 5) If 15 workers can build a wall in 48 hours, how many workers are needed to build the same wall in 30 hours?\n',
        choices: [
            'A) 20',
            'B) 24',
            'C) 30',
            'D) 32'
        ],
    });

    return handleAnswer(answers.question_5 === 'B) 24');
}

function winner() {
    console.clear();
    const msg = `Congrats ,${playerName} !\n $ 1 . 0 0 0 , 0 0 0`;

    figlet(msg, (err, data) => {
        console.log(gradient.pastel.multiline(data));
    });

}


await welcome()
await askName()
await question1()
await question2()
await question3()
await question4()
await question5()
winner();

